# PLACE Motif Analysis Output

This folder contains the PLACE cis-regulatory motif predictions for the TaNPF2.12 promoter.

Files included:
- PLACE_output_TaNPF2.12.txt: Raw motif output.
- motif_summary_table.txt: Summary of GCCCORE motif positions.
- motif_map.png: Diagram of ERF-binding sites.

