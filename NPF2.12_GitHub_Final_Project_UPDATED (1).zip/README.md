# NPF2.12 Nitrogen Use Efficiency Analysis

This repository contains R code and data structures used to analyse natural variation in **TaNPF2.12** haplotypes and their effects on root traits, nitrogen use efficiency (NUE), and grain yield across multiple environments.

## Folder structure

- `data/`
  - `pheno_project_with_snps_two_seasons_data.xlsx` – main phenotype dataset (two seasons, two sites, HN/LN).
  - `TaNPF2.12_promoter_filtered_SNPs.csv` – filtered promoter/coding SNPs (−88 and +4 positions).
  - `haplotypes.csv` – optional pre-computed haplotype table (can be generated from SNPs).
- `scripts/` – R scripts to reproduce all analyses and figures.
- `figures/` – output plots (boxplots, reaction norms, PCA).
- `results/` – statistical summaries (ANOVA tables, plasticity tables, PCA loadings).
- `docs/`
  - `promoter_motif_analysis/` – PLACE motif output and notes.
  - `alignments/` – sequence alignments (if desired).

## Running the pipeline

1. Open the project root in RStudio.
2. Ensure that the Excel phenotype file in `data/` has the filename:
   `pheno_project_with_snps_two_seasons_data.xlsx`.
3. Run the scripts in the following order:

   ```r
   source("scripts/01_load_packages.R")
   source("scripts/02_load_data.R")
   source("scripts/03_clean_merge.R")
   source("scripts/04_trait_boxplots.R")
   source("scripts/05_anova_models.R")
   source("scripts/06_plasticity_slopes.R")
   source("scripts/07_environment_stability.R")
   source("scripts/08_pca_analysis.R")
   ```

4. Figures will be written into `figures/` and summary tables into `results/`.

All scripts are written for transparency and reproducibility and can be customised for additional traits or environments.
