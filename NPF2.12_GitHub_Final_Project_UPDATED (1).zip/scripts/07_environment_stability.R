# Environment-specific means and stability plot

env_means <- df %>%
  group_by(Environment, Haplotype) %>%
  summarise(
    RootLength_mean = mean(RootLength, na.rm = TRUE),
    Volume_mean     = mean(Volume, na.rm = TRUE),
    NUE_mean        = mean(NUE, na.rm = TRUE),
    GrainYield_mean = mean(GrainYield, na.rm = TRUE),
    .groups = "drop"
  )

write.csv(env_means, "results/environment_trait_means_by_haplotype.csv", row.names = FALSE)

p_env_nue <- env_means %>%
  ggplot(aes(x = Environment, y = NUE_mean, group = Haplotype, color = Haplotype)) +
  geom_line(size = 1.2) +
  geom_point(size = 3) +
  theme_bw(base_size = 14) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(y = "Mean NUE", x = "Environment")
print(p_env_nue)
ggsave("figures/environment_stability_NUE.png", p_env_nue, width = 8, height = 5, dpi = 300)
