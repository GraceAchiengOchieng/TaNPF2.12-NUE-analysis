# Load phenotype data from Excel
pheno_raw <- readxl::read_excel("data/pheno_project_with_snps_two_seasons_data.xlsx")

# Inspect
str(pheno_raw)
head(pheno_raw)
