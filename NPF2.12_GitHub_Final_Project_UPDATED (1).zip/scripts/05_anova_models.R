# Two-way ANOVA: Promoter x Coding for each trait

traits_core <- c("RootLength","Volume","NUE","GrainYield")

anova_list <- list()

for(tr in traits_core){
  f <- as.formula(paste(tr, "~ Promoter * Coding"))
  fit <- aov(f, data = df)
  anova_list[[tr]] <- summary(fit)
  sink(paste0("results/anova_", tr, ".txt"))
  cat("ANOVA for", tr, "\n")
  print(summary(fit))
  sink()
}

# Example of post-hoc for one trait (extend as needed)
# library(emmeans)
# fit_rl <- aov(RootLength ~ Promoter * Coding, data = df)
# emmeans(fit_rl, pairwise ~ Promoter * Coding)
