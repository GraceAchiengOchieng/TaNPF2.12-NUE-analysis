
# Environment-specific boxplots
library(tidyverse)

for(tr in c("RootLength","Volume","NUE","GrainYield")){
  p <- ggplot(df, aes(x=Environment, y=.data[[tr]], fill=Environment)) +
       geom_boxplot(alpha=.7) +
       theme_bw(base_size=14) +
       theme(axis.text.x=element_text(angle=45,hjust=1)) +
       labs(x="Environment", y=tr)
  ggsave(paste0("figures/environment_boxplot_",tr,".png"), p, width=8,height=5,dpi=300)
}
