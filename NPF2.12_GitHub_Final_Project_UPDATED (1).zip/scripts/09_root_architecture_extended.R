
# Extended analysis for root architecture traits
library(tidyverse)
df <- df

traits_ext <- c("RootArea","SurfaceArea","AvgDiameter","LengthPerVolume","Tips","Forks","Crossings")

for(tr in traits_ext){
  p <- ggplot(df, aes(x=Haplotype, y=.data[[tr]], fill=Haplotype)) +
       geom_boxplot(outlier.shape=NA, alpha=.7) +
       geom_jitter(aes(color=Environment), width=.18, size=2) +
       theme_bw(base_size=14) +
       labs(x="Haplotype", y=tr)
  print(p)
  ggsave(paste0("figures/boxplot_",tr,".png"), p, width=7,height=5,dpi=300)
}
