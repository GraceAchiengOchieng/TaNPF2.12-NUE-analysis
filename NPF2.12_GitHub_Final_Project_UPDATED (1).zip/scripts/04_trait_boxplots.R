# Boxplots for key traits by haplotype with environment dots

plot_trait_box <- function(trait){
  p <- ggplot(df, aes(x = Haplotype, y = .data[[trait]], fill = Haplotype)) +
    geom_boxplot(outlier.shape = NA, alpha = 0.7) +
    geom_jitter(aes(color = Environment), width = 0.18, size = 2, alpha = 0.8) +
    theme_bw(base_size = 14) +
    labs(x = "Haplotype", y = trait, color = "Environment") +
    theme(legend.position = "right")
  print(p)
  ggsave(filename = paste0("figures/boxplot_", trait, ".png"),
         plot = p, width = 7, height = 5, dpi = 300)
}

traits_core <- c("RootLength","Volume","NUE","GrainYield")

for(tr in traits_core){
  plot_trait_box(tr)
}
