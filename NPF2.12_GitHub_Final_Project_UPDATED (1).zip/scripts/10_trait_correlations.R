
# Correlation matrix for traits
library(tidyverse)
library(GGally)

num_traits <- df %>% 
  select(RootLength, Volume, RootArea, SurfaceArea, AvgDiameter, LengthPerVolume, NUE, GrainYield)

png("figures/trait_correlation_matrix.png", width=900, height=900)
print(GGally::ggpairs(num_traits))
dev.off()
