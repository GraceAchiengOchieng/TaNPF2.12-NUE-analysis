# Clean and prepare main analysis data frame

df <- pheno_raw %>%
  # standardise column names if necessary
  rename(
    Site      = site,
    Genotype  = genotype,
    Treatment = treatment,
    Year      = year,
    RootLength = root_length,
    RootArea   = root_area,
    SurfaceArea = surface_area,
    AvgDiameter = avg_diameter,
    LengthPerVolume = length_per_volume,
    Volume     = volume,
    Tips       = tips,
    Forks      = forks,
    Crossings  = crossings,
    N_content  = n_content,
    TKW        = tkw,
    GrainYield = grain_yield,
    NUE        = NUE,
    Pos_m88    = Pos_-88,
    Pos_4bp    = Pos_4
  ) %>%
  mutate(
    # factors
    Site      = factor(Site),
    Genotype  = factor(Genotype),
    Treatment = factor(Treatment, levels = c("LN","HN")),
    Year      = factor(Year),
    # derive promoter / coding alleles and clean haplotype label
    Promoter  = if_else(Pos_m88 == "C", "C", "T"),
    Coding    = if_else(Pos_4bp == "G", "G", "C"),
    Haplotype = factor(paste0(Promoter, "_", Coding)),
    Environment = factor(paste(Site, Year, sep = "_"))
  )

# Quick check
summary(df$Haplotype)
table(df$Environment, df$Treatment)
