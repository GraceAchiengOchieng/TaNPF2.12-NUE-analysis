# Plasticity: reaction norms LN -> HN per haplotype

# Aggregate means by Haplotype x Treatment
plast <- df %>%
  group_by(Haplotype, Treatment) %>%
  summarise(
    RootLength_mean = mean(RootLength, na.rm = TRUE),
    Volume_mean     = mean(Volume, na.rm = TRUE),
    NUE_mean        = mean(NUE, na.rm = TRUE),
    GrainYield_mean = mean(GrainYield, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_wider(names_from = Treatment,
              values_from = c(RootLength_mean, Volume_mean, NUE_mean, GrainYield_mean))

# Save table
write.csv(plast, "results/plasticity_means_LN_HN_by_haplotype.csv", row.names = FALSE)

# Reaction norm plot for NUE as example
p_nue <- df %>%
  group_by(Haplotype, Treatment) %>%
  summarise(NUE_mean = mean(NUE, na.rm = TRUE), .groups = "drop") %>%
  ggplot(aes(x = Treatment, y = NUE_mean, group = Haplotype, color = Haplotype)) +
  geom_line(size = 1.2) +
  geom_point(size = 3) +
  theme_bw(base_size = 14) +
  labs(y = "Mean NUE", x = "Nitrogen treatment")
print(p_nue)
ggsave("figures/reaction_norm_NUE.png", p_nue, width = 7, height = 5, dpi = 300)
