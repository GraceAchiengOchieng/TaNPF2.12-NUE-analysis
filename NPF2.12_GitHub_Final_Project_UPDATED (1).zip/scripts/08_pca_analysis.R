# PCA on key traits to visualise multi-environment structure

traits_pca <- df %>%
  select(RootLength, Volume, NUE, GrainYield) %>%
  drop_na()

pca_res <- prcomp(traits_pca, scale. = TRUE)

# Save loadings
loadings <- as.data.frame(pca_res$rotation)
write.csv(loadings, "results/pca_loadings.csv")

# Biplot coloured by Haplotype
p_pca <- factoextra::fviz_pca_biplot(
  pca_res,
  geom.ind = "point",
  habillage = df$Haplotype,
  addEllipses = TRUE,
  repel = TRUE
)
ggsave("figures/pca_biplot.png", p_pca, width = 7, height = 6, dpi = 300)
